<?php
/**
 * Republic of Malta places
 *
 * @author   Sergio Caramanno
 * @version  2020-03-24
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * Data from: http://geonames.org/
 */

return [

];
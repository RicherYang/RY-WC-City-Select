<?php
/**
 * Sultanate of Oman places
 *
 * @author   Sergio Caramanno
 * @version  2020-03-24
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * Data from: http://geonames.org/
 */

return [
	'OM' => [
	'MU' => [
		_x('Madha', 'MU', 'ry-wc-city-select'),
	],
	]
];